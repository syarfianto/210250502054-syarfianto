/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GajiKarywan;

/**
 *
 * @author SYARFIANTO
 */
public class Program3kondisi {
    public static void main(String[] args) {
        int gaji = 4000000;
        
        if (gaji >= 5000000){
            System.out.println("Gaji akutansi");
            
        }
        else if (gaji >= 3500000){
            System.out.println("Gaji kasir");
        }
        else if (gaji >= 1500000) {
            System.out.println("Gaji junior supervisor");
        }
        else {
            System.out.println("pramuniaga");
        
        }
        
    }
    
}

